// src/lib/config.ts
export const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL!;
export const SYMBOLS_URL = process.env.NEXT_PUBLIC_SYMBOLS_URL!;
export const WS_URL = process.env.NEXT_PUBLIC_WS_URL!;
