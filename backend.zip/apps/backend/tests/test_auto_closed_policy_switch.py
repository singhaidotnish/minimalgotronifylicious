def test_auto_closed_policy_switch(monkeypatch):
    monkeypatch.setenv("BROKER", "auto")
    # pretend registry default when_closed is paper_trade
    # assert resolve_broker_name("auto", False) == "paper_trade"
    # change YAML to binance and assert that behavior instead
