cd ~/Documents/GitHub/algomin
source .algo/bin/activate
pip install -e .
