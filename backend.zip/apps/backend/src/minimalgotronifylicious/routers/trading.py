from __future__ import annotations
import os, uuid
from typing import Optional, Literal, Any, Dict

from fastapi import APIRouter, Depends, Header, HTTPException, Body
from pydantic import BaseModel, Field

from src.minimalgotronifylicious.brokers.order_client_factory import (
    order_client_factory, resolve_broker_name
)
from src.minimalgotronifylicious.utils.circuit_breaker import Circuit
from src.minimalgotronifylicious.utils.symbols import normalize
from src.minimalgotronifylicious.utils.price import extract_price
from src.minimalgotronifylicious.utils.broker_registry import get_symbols_provider

router = APIRouter(prefix="/api", tags=["trading"])
circuit = Circuit()
_IDEM: Dict[str, Dict[str, Any]] = {}

class LtpResp(BaseModel):
    symbol: str
    ltp: float
    ts: int

class OrderRequest(BaseModel):
    symbol: str
    qty: float
    side: Literal["BUY","SELL"] = "BUY"
    type: Literal["MARKET","LIMIT"] = "MARKET"
    price: Optional[float] = None

class OrderResp(BaseModel):
    orderId: str
    status: Literal["ACCEPTED","REJECTED","PENDING"]
    message: Optional[str] = None

def client_dep(
    x_broker: Optional[str] = Header(default=None, convert_underscores=False),
    x_market_open: Optional[str] = Header(default=None, convert_underscores=False),
):
    broker = (x_broker or os.getenv("BROKER","auto")).strip().lower().replace("-","_")
    market_open = (x_market_open or "").strip().lower() in ("1","true","yes","on")

    if broker == "angel_one":
        from src.minimalgotronifylicious.sessions.angelone_session import AngelOneSession
        sess = AngelOneSession.from_env()
        return order_client_factory("angel_one", session=sess)

    return order_client_factory(broker, market_open=market_open)

@router.get("/symbols")
def symbols(
    x_broker: Optional[str] = Header(default=None, convert_underscores=False),
    x_market_open: Optional[str] = Header(default=None, convert_underscores=False),
):
    market_open = (x_market_open or "").strip().lower() in ("1","true","yes","on")
    name = resolve_broker_name(x_broker or os.getenv("BROKER","auto"), market_open)
    provider = get_symbols_provider(name)
    return {"broker": name, "items": provider()}

@router.get("/ltp", response_model=LtpResp)
def ltp(symbol: str, client = Depends(client_dep)):
    ex, token, combined = normalize(symbol)
    try:
        raw = client.ltp(combined)
    except TypeError:
        raw = client.ltp(exchange=ex, symbol=token)
    return LtpResp(symbol=combined, ltp=extract_price(raw), ts=__import__("time").time_ns()//1_000_000)

@router.post("/order", response_model=OrderResp)
def order(
    req: OrderRequest,
    client = Depends(client_dep),
    request_id: Optional[str] = Header(default=None, convert_underscores=False, alias="X-Request-Id"),
):
    if circuit.open():
        raise HTTPException(status_code=503, detail="Circuit open")
    if not request_id:
        raise HTTPException(status_code=400, detail="Missing X-Request-Id")

    key = f"order:{request_id}"
    if key in _IDEM:
        return _IDEM[key]

    # Paper/live distinction is inside the adapter or via env; just try
    try:
        result = client.place_order(**(req.model_dump() if hasattr(req,"model_dump") else req.dict()))
        order_id = str(result.get("order_id") or result.get("orderId") or uuid.uuid4())
        status = str(result.get("status") or "ACCEPTED").upper()
        message = result.get("message")
        resp = OrderResp(orderId=order_id, status=status, message=message).model_dump()
        circuit.ok()
    except Exception as e:
        circuit.fail()
        raise HTTPException(status_code=502, detail=f"Broker error: {type(e).__name__}: {e}") from e

    _IDEM[key] = resp
    return resp
