from setuptools import setup, find_packages

setup(
    name="minimalgotronifylicious",
    version="0.1.0",
    packages=find_packages(),  # should find "minimalgotronifylicious"
    install_requires=[],
)
